from imutils import contours
import numpy as np
import argparse
import cv2

